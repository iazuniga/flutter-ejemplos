package com.example.app_crud_basic

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
